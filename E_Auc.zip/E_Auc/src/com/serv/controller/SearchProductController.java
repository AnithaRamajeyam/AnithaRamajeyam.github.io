package com.serv.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.serv.beans.SearchProduct;
import com.serv.service.SearchProductService;
import com.serv.service.SearchProductServiceImpl;



@WebServlet("/SearchController")
public class SearchProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SearchProductService ser=new SearchProductServiceImpl();
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		SearchProduct sp=new SearchProduct(request.getParameter("product"));
		List<SearchProduct> search=ser.getProductInfo(sp);
		pw.println("<table border=1>");
		pw.println("<tr><th>Product_name</th><th>Short_desc</th></tr>");
		for(SearchProduct s:search)
		{
			pw.println("<tr><td>"+s.getProduct_name()+"</td><td>"+s.getShort_desc()+"</td></tr>");
		}
		pw.println("</table>");
		
		pw.close();
	}


}
