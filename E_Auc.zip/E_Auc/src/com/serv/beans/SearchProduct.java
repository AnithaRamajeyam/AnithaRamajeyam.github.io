package com.serv.beans;

public class SearchProduct {

		String category;
		String Product_name;
		String Short_desc;
		public SearchProduct(String category) {
			super();
			this.category = category;
		}
		public SearchProduct(String product_name, String short_desc) {
			super();
			Product_name = product_name;
			Short_desc = short_desc;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public String getProduct_name() {
			return Product_name;
		}
		public void setProduct_name(String product_name) {
			Product_name = product_name;
		}
		public String getShort_desc() {
			return Short_desc;
		}
		public void setShort_desc(String short_desc) {
			Short_desc = short_desc;
		}
		
		
		
}
