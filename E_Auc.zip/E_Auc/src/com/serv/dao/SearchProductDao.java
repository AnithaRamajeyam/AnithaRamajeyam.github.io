package com.serv.dao;

import java.util.List;

import com.serv.beans.SearchProduct;

public interface SearchProductDao {
	
	public List<SearchProduct> getProductInfo(SearchProduct sp);
}
