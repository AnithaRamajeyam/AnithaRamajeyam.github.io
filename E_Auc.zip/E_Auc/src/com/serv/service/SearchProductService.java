package com.serv.service;

import java.util.List;

import com.serv.beans.SearchProduct;

public interface SearchProductService {
	
	public List<SearchProduct> getProductInfo(SearchProduct sp);

}
